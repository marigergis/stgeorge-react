const HandymanPage = () => {
  return (
    <section>
        <h1 className="text-center">Handyman</h1>
        <ul>
          <li>
            <a
              className="text-decoration-none link-secondary"
              href="https://youtu.be/1mn4CShD3ps?si=nDTb2hdAvyrloYiX"
              >How to clean a bathroom fan?</a
            >
          </li>
        </ul>

    </section>
  );
};
export default HandymanPage;
