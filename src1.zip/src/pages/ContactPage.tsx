const ContactPage = () => {
    return (
      <section>
        <h1>Contact Us</h1>
      </section>
    );
};
export default ContactPage;
  