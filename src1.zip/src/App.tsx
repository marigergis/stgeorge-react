import "./App.css";
import { Link, Outlet } from "react-router-dom";

function App() {
  return (
    <>
      <nav>
        <Link to="/stgeorge-react/">Home</Link>
        {" | "}
        <Link to="/stgeorge-react/arabic">Arabic</Link>
      </nav>

      <Outlet />
    </>
  );
}

export default App;